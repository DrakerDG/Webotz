/*
 * File:          wheelchair_V1_C.c
 * Date:          03-26-2022
 * Description:   wheelchair controller
 * Author:        DrakerDG
 * Modifications: 1
 */

#include <stdio.h>
#include <webots/robot.h>
#include <webots/motor.h>

int timestep = 0;
int left_speed = 1;
int right_speed = -1;  
int turn = 0;

// Motors
WbDeviceTag left_motor, right_motor;

int main(int argc, char **argv) {
  wb_robot_init();

  // Initalize time step
  timestep = wb_robot_get_basic_time_step();

  // Intialize motors
  left_motor = wb_robot_get_device("left motor");
  right_motor = wb_robot_get_device("right motor");
  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);
  wb_motor_set_velocity(left_motor, left_speed);
  wb_motor_set_velocity(right_motor, right_speed);

  // main loop
  while (wb_robot_step(timestep) != -1) {
  
    if (turn > 300) {
      left_speed = -left_speed;
      right_speed = -right_speed;
      wb_motor_set_velocity(left_motor, left_speed);
      wb_motor_set_velocity(right_motor, right_speed);
      turn = 0;
    }
    turn += 1;
    
  };

  wb_robot_cleanup();
  return 0;
}
