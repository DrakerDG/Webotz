/*
 * File:          SLFR_V6_C.c
 * Date:          2021-nov
 * Description:   V5
 * Author:        DrakerDG
 * Modifications: latest
 */

#include <stdio.h>
#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/distance_sensor.h>
#include <webots/camera.h>
#include <webots/led.h>
#include <webots/supervisor.h>

int time_step = 0;

// Motors

WbDeviceTag left_motor, right_motor;

// IR Ground Sensors
WbDeviceTag gs[8];

// LEDs
WbDeviceTag led[5];

// Robot
WbNodeRef robotX;

// PID
int Kp = 25; // 14;
float Ki = 0.03; // 0.02;
float Kd = 0.16; //0.12;

float P = 0;
float I = 0;
float D = 0;
float oldP = 0;
float PID = 0;

// Max velocity 132
#define maxS 132

// Speed Motors
float left_speed = 0;
float right_speed = 0;

// Error Position Function
int Error_Position(int Pos){
  int online = 0;
  unsigned PosX = 0;
  
  for(int i = 0; i < 8; i++){
    // Read Sensor and if > 200
    if(wb_distance_sensor_get_value(gs[i]) > 200){
      PosX += i;
      online += 1;
    }
  }
  
  // If outline sensor, retur the latest position
  if(online == 0) return Pos;
  return PosX / online -3.5;
}

// Line Following Module
void LineFollowingModule(void){
  float medS = 0;
  // Error Position Calculation & PID
  P = Error_Position(P);
  I += P * time_step / 1000;
  D = D * 0.5 + (P - oldP) / time_step * 1000;
  
  PID = Kp * P + Ki * I + Kd * D;
  
  oldP = P;
  
  medS = maxS - abs(PID);
  left_speed = medS + PID;
  right_speed = medS - PID;
}

void PosLED(void){
  // Center green LED
  if((P > -1) && (P < 1)) wb_led_set(led[1], 1);
  else wb_led_set(led[1], 0);
  
  // left blue LED
  if(P < -0.8) wb_led_set(led[0], 1);
  else wb_led_set(led[0], 0);

  // Right blue LED
  if(P > 0.8) wb_led_set(led[2], 1);
  else wb_led_set(led[2], 0);
}

// main program.
int main(int argc, char **argv) {
  int i;
  char name[20];
  char strP[20];
  double velocity = 0;
  double maxV = 0;

  // Initialize robot
  wb_robot_init();

  // Initialize time step
  time_step = wb_robot_get_basic_time_step();
  
  // Initialize motors
  left_motor = wb_robot_get_device("left wheel motor");
  right_motor = wb_robot_get_device("right wheel motor");
  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);
  wb_motor_set_velocity(left_motor, 0.0);
  wb_motor_set_velocity(right_motor, 0.0);

  // Initialize IR Ground Sensors
  for (i = 0; i < 8; i++){
    sprintf(name, "gs%d", i);
    gs[i] = wb_robot_get_device(name);
    wb_distance_sensor_enable(gs[i], time_step);
  }

  // Initialize camera
  WbDeviceTag camera = wb_robot_get_device("camera");
  wb_camera_enable(camera, time_step);
  
  // Initialize LEDs
  for (i = 0; i < 5; i++){
    sprintf(name, "led%d", i);
    led[i] = wb_robot_get_device(name);
    // Turn on LED
    wb_led_set(led[i], 1);
  }

  while (wb_robot_step(time_step) != -1) {
  
    LineFollowingModule();
    
    PosLED();
    
    wb_motor_set_velocity(left_motor, left_speed);
    wb_motor_set_velocity(right_motor, right_speed);
    
    // Get Velocity
    robotX = wb_supervisor_node_get_self();
    
    const double *velo = wb_supervisor_node_get_velocity(robotX);
    
    // Velocity calulation:  Speed Module (x, y, z)
    velocity = pow(pow(velo[0], 2) + pow(velo[1], 2) + pow(velo[2], 2), 0.5);
    
    if (velocity > maxV) maxV = (velocity + maxV) / 2;
    
    sprintf(strP, "Speed: %.2f m/s  Max: %.2f m/s", velocity, maxV);
    
    // Print Speed
    wb_supervisor_set_label(0, strP, 0, 0.94, 0.05, 0x165282, 0, "Lucida Console");

  };

  wb_robot_cleanup();

  return 0;
}
