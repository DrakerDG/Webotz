"""SLFR_V5_P controller."""

from controller import Supervisor

# create the Robot instance.
robot = Supervisor()

robotNode = robot.getSelf()

Kp = 25 #14
Ki = 0.03 #0.02
Kd = 0.16 #0.12

P = 0
I = 0
D = 0

oldP = 0
maxS = 132
maxV = 0

# get the time step of the current world.
time_step = int(robot.getBasicTimeStep())

# Initialize Motors
left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))

left_speed = 0
right_speed = 0

left_motor.setVelocity(left_speed)
right_motor.setVelocity(right_speed)

# Initialize Ground Sensors
gss = []

for i in range(8):
    gs = robot.getDevice('gs'  + str(i))
    gs.enable(time_step)
    gss.append(gs)
    
# Initialize LEDs
leds = []

for i in range(5):
    led = robot.getDevice('led' + str(i))
    leds.append(led)
    led.set(1)

# Initialize camera
camera = robot.getDevice('camera')
camera.enable(time_step)

def Error_Position(Pos):
    online = 0
    PosX = 0
    for i in range(8):
        # Read Sensor and if > 200
        if gss[i].getValue() > 200:
            PosX += i
            online += 1
    
    # If outline sensor, retur the latest position
    if online == 0:
        return Pos
    
    return PosX / online -3.5

def posLED():
    # Center green LED
    if P > -1 and P < 1:
        leds[1].set(1)
    else:
        leds[1].set(0)
        
    # left blue LED
    if P < -0.8:
        leds[0].set(1)
    else:
        leds[0].set(0)

    # Right blue LED
    if P > 0.8:
        leds[2].set(1)
    else:
        leds[2].set(0)


# Main loop:
while robot.step(time_step) != -1:

    # Error Position Calculation & PID
    P = Error_Position(P)
    I += P * time_step / 1000
    D = D * 0.5 + (P - oldP) / time_step * 1000
    
    PID = Kp * P + Ki * I + Kd * D
    
    oldP = P
    
    medS = maxS - abs(PID)
    left_speed = medS + PID
    right_speed = medS - PID
    
    posLED()
    
    left_motor.setVelocity(left_speed)
    right_motor.setVelocity(right_speed)

    # Get Velocity
    velo = robotNode.getVelocity()
    
    # Velocity calulation:  Speed Module (x, y, z)
    velocity = (velo[0]**2 + velo[1]**2 + velo[2]**2)**0.5
    
    if velocity > maxV:
        maxV = (velocity + maxV) / 2
        
    strP = f'Speed: {velocity:.2f} m/s  Max {maxV:.2f} m/s'
    
    robot.setLabel(0, strP, 0, 0.97, 0.05, 0x165282, 0, 'Lucida Console')
    
    pass

# Enter here exit cleanup code.
