/*
 * File:          SLFR_V6.c
 */

#include <stdio.h>
#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/distance_sensor.h>
#include <webots/led.h>
#include <webots/camera.h>
#include <webots/supervisor.h>

int timestep = 0;

// PID
float Kp = 20;   // 20
float Ki = 0.02; // 0.02
float Kd = 0.2;  // 0.2

float P = 0;
float I = 0;
float D = 0;
float oldP = 0;
float PID = 0;

// Max velocity 150
#define maxS 150

// Speed Motors
float left_speed = 0;
float right_speed = 0;

// Motors

WbDeviceTag left_motor, right_motor;

// IR Ground Sensors

WbDeviceTag gs[8];

// LEDs
WbDeviceTag led[5];

// Robot
WbNodeRef robotX;

// Error Position Function
int Error_Position(int Pos){
  int online = 0;
  unsigned PosX = 0;
  
  for(int i = 0; i < 8; i++){
    // Read the black line if value > 200
    if(wb_distance_sensor_get_value(gs[i]) > 200){
      PosX += i;
      online += 1;
    }
  }
  
  // If outline sensor, retur the lastest position
  if (online == 0) return Pos;
  return PosX / online - 3.5;
}

// line Following Module
void LineFollowingModule(void){
  float medS = 0;
  // Error Pisition Calculation & PID
  P = Error_Position(P);
  I += P * timestep / 1000;
  D = D * 0.5 + (P - oldP) / timestep * 1000;
  
  PID = Kp * P + Ki * I + Kd * D;
  
  oldP = P;
  
  medS = maxS - abs(PID);
  left_speed = medS + PID;
  right_speed = medS - PID; 
}

void PosLED(void){
  // Center green lED
  if((P > -1) && (P < 1)) wb_led_set(led[1], 1);
  else wb_led_set(led[1], 0);
  
  // left blue lED
  if(P < -0.8) wb_led_set(led[0], 1);
  else wb_led_set(led[0], 0);

  // right blue lED
  if(P > 0.8) wb_led_set(led[2], 1);
  else wb_led_set(led[2], 0);
}

int main(int argc, char **argv) {
  int i;
  char name[20];
  char strP[20];
  double velocity = 0;
  double maxV = 0;

  wb_robot_init();
  
  // Initalize time step
  timestep = wb_robot_get_basic_time_step();
  
  // Initialize motors
  left_motor = wb_robot_get_device("left rotational motor");
  right_motor = wb_robot_get_device("right rotational motor");
  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);
  wb_motor_set_velocity(left_motor, 0);
  wb_motor_set_velocity(right_motor, 0);
  
  // Initialize IR Ground Sensors
  for (i = 0; i < 8; i++){
    sprintf(name, "gs%d", i);
    gs[i] = wb_robot_get_device(name);
    wb_distance_sensor_enable(gs[i], timestep);
  }
  
  // Initialize LEDs
  for (i = 0; i < 5; i++){
    sprintf(name, "led%d", i);
    led[i] = wb_robot_get_device(name);
    // Turn on LED
    wb_led_set(led[i], 1);
  }

  // Initialize camera
  WbDeviceTag camera = wb_robot_get_device("camera");
  wb_camera_enable (camera, timestep);
  
  /* main loop */
  while (wb_robot_step(timestep) != -1) {
  
    LineFollowingModule();
    
    PosLED();
    
    wb_motor_set_velocity(left_motor, left_speed);
    wb_motor_set_velocity(right_motor, right_speed);
      
    // Get Velocity
    robotX = wb_supervisor_node_get_self();
    
    const double *sp = wb_supervisor_node_get_velocity(robotX);
    
    // Velocity calculation: Speed Module  (x, y, z)
    velocity = pow(pow(sp[0], 2) + pow(sp[1], 2) + pow(sp[2], 2), 0.5);
    
    if (velocity > maxV) maxV = (velocity + maxV) / 2;
    
    sprintf(strP, "Speed: %.2f m/s  Max: %.2f m/s", velocity, maxV);
    
    // Print Speed
    wb_supervisor_set_label(0, strP, 0, 0.94, 0.05, 0x000000, 0, "Lucida Console");
    
  };

  wb_robot_cleanup();

  return 0;
}
