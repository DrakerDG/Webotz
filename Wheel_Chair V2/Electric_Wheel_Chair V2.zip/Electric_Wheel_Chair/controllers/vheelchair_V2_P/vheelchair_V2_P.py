"""vheelchair_V2_P controller."""

from controller import Robot

MAX_SP = 10
MIN_DT = 750

MAX_TM = 0

timestep = 0
left_speed = MAX_SP
right_speed = MAX_SP
turn = 0
timer = 0

# create the Robot instance.
robot = Robot()

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())

MAX_TM = 3840 / timestep / MAX_SP

# Initialize Motors
left_motor = robot.getDevice('left motor')
right_motor = robot.getDevice('right motor')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(left_speed)
right_motor.setVelocity(right_speed)

# Initialize IR Sensors
IR = []
SV = [0, 0, 0, 0, 0, 0, 0, 0]

for i in range(8):
    irs = robot.getDevice('IR'  + str(i))
    irs.enable(timestep)
    IR.append(irs)

# Initialize camera
camera = robot.getDevice('camera')
camera.enable(timestep * 4)


def Obstacle_Detection():
    go_turn = 0
    
    for i in range(8): SV[i] = IR[i].getValue()

    if SV[1] < MIN_DT * 0.8 or SV[2] < MIN_DT or SV[3] < MIN_DT * 0.8: go_turn = 1
    if SV[1] > SV[3]: go_turn *= -1
    
    return go_turn

def Set_Direction():
    global turn
    global timer
    global left_speed
    global right_speed
    
    if turn == 0: turn = Obstacle_Detection()
    else:
        if timer == 0:
            left_speed = MAX_SP * turn
            right_speed = - MAX_SP * turn
        timer += 1
        if timer > MAX_TM:
            left_speed = MAX_SP
            right_speed = MAX_SP
            timer = 0
            turn = 0

    left_motor.setVelocity(left_speed)
    right_motor.setVelocity(right_speed)

# Main loop:
while robot.step(timestep) != -1:
    
    Set_Direction()

    pass