/*
 * File:          wheelchair_V2_C.c
 * Date:          03-26-2022
 * Description:   wheelchair controller
 * Author:        DrakerDG
 * Modifications: 1
 */

#include <stdio.h>
#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/distance_sensor.h>
#include <webots/camera.h>

#define MAX_SP 10
#define MIN_DT 750

int MAX_TM = 0;

int timestep = 0;
int left_speed = MAX_SP;
int right_speed = MAX_SP;  
int turn = 0;
int timer = 0;

// Motors
WbDeviceTag left_motor, right_motor;

// IR Sensors
WbDeviceTag IR[8]; /* IR sensors */



int Obstacle_Detection(void) {
  int go_turn = 0;
  int SV[8] = {0, 0, 0, 0, 0, 0, 0, 0};
  
  for (int i = 0; i < 8; i++) {
    SV[i] = wb_distance_sensor_get_value(IR[i]);
  }

  if (SV[1] < MIN_DT * 0.8 || SV[2] < MIN_DT || SV[3] < MIN_DT * 0.8) go_turn = 1;
  if (SV[1] > SV[3]) go_turn *= -1;
  return go_turn;  
}

void Set_Direction(void) {
  if (turn == 0) turn = Obstacle_Detection();
  else {
    if (timer == 0) {
      left_speed = MAX_SP * turn;
      right_speed = - MAX_SP * turn;
    }
    timer += 1;
    if (timer > MAX_TM) {
      left_speed = MAX_SP;
      right_speed = MAX_SP;
      timer = 0;
      turn = 0;
    }
  }
  wb_motor_set_velocity(left_motor, left_speed);
  wb_motor_set_velocity(right_motor, right_speed);
}


int main(int argc, char **argv) {
  char name[20];

  wb_robot_init();

  // Initalize time step
  timestep = wb_robot_get_basic_time_step();

  MAX_TM = 3840 / timestep / MAX_SP;

  // Intialize motors
  left_motor = wb_robot_get_device("left motor");
  right_motor = wb_robot_get_device("right motor");
  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);
  wb_motor_set_velocity(left_motor, left_speed);
  wb_motor_set_velocity(right_motor, right_speed);

  // Intialize IR sensors
  for (int i = 0; i < 8; i++) {
    sprintf(name, "IR%d", i);
    IR[i] = wb_robot_get_device(name);
    wb_distance_sensor_enable(IR[i], timestep);
  }

  // Intialize camera
  WbDeviceTag camera = wb_robot_get_device("camera");
  wb_camera_enable(camera, timestep * 4);

  // main loop
  while (wb_robot_step(timestep) != -1) {
    
    Set_Direction();  

  };

  wb_robot_cleanup();
  return 0;
}
