/*
 * File:          e-puck_LF_V1.c
 * Date:          2022-jan
 * Description:   Line Follower Example
 * Author:        DrakerDG
 * Modifications: 2
 */

#include <stdio.h>
#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/distance_sensor.h>
#include <webots/camera.h>


// Global defines
#define TRUE 1
#define FALSE 0
#define LEFT 0
#define RIGHT 1
#define TIME_STEP 32  // [ms]

// 3 IR ground color sensors
#define NB_GROUND_SENS 3
WbDeviceTag gs[NB_GROUND_SENS]; /* ground sensors */
unsigned short gs_value[NB_GROUND_SENS] = {0, 0, 0};

// Motors
WbDeviceTag left_motor, right_motor;

#define MAX_GS 880 //840
#define MIN_GS 300
#define NEW_GS 1000
#define GOAL 346 //Green of Goal!!!

bool ontrack = TRUE;
bool online = FALSE;

short gs_new[NB_GROUND_SENS] = {0, 0, 0};

unsigned long Position = 0;

int lfm_speed[2];

// PID errors
long P = 0;
long I = 0;
long D = 0;
long PID = 0;
long P_old = 0;

// PID factors
float Kp = 0.1;   // 0.1
float Ki = 0.0002; // 0.0002
float Kd = 0.002;  // 0.002

// Speed Base
#define LFM_FORWARD_SPEED 500

// Read Ground Sensors Module
void ReadGroundSensors(void){
  online = false;
  unsigned long avgS = 0;
  unsigned int sumS = 0;
    
  for(int i=0; i<NB_GROUND_SENS; i++){
    gs_value[i] = wb_distance_sensor_get_value(gs[i]);

    // linear Interpolation
    gs_new[i] = ((float)gs_value[i]-MIN_GS)/(MAX_GS-MIN_GS)*-NEW_GS+NEW_GS;

    // Limited values between 0 and 1000 (NEW_GS)
    if(gs_new[i]>NEW_GS) gs_new[i]=NEW_GS;
    if(gs_new[i]<0) gs_new[i]=0;
    
    if(gs_new[i]>200)online = TRUE;
    if(gs_new[i]>50){
      // Average groud sensor value
      avgS += (unsigned long)gs_new[i]*(i*NEW_GS);
      // Sum ground sensor value
      sumS += gs_new[i];
    }
  }
  if(online)Position = avgS/sumS; // Position Calculation
  else if(Position < NEW_GS)Position = 0; // Left Sensor Memory Position
  else Position = NEW_GS*2; // Right Sensor Memory Position

//  printf("GS val: %4d %4d %4d  \n", gs_value[0], gs_value[1], gs_value[2]);
//  printf("GS new: %4d %4d %4d  \n", gs_new[0], gs_new[1], gs_new[2]);

}


// Line Following Module
void LineFollowingModule(void) {
  // Error Position Calculation PID
  P = Position - NEW_GS;
  I = P * TIME_STEP / 1000 ;
  D = D * 0.5 + (P - P_old) / TIME_STEP * 1000;

  PID = Kp * P + Ki * I + Kd * D;
  
  P_old = P;
  
  lfm_speed[LEFT] = LFM_FORWARD_SPEED + PID;
  lfm_speed[RIGHT] = LFM_FORWARD_SPEED - PID;
  
  if(lfm_speed[LEFT] > 1000) lfm_speed[LEFT] = 1000;
  else if(lfm_speed[LEFT] < -1000) lfm_speed[LEFT] = -1000;
  if(lfm_speed[RIGHT] > 1000) lfm_speed[RIGHT] = 1000;
  else if(lfm_speed[RIGHT] < -1000) lfm_speed[RIGHT] = -1000;

  printf("%4d   %4d   %4d   %5d   OnLine: %d \n", gs_new[0], gs_new[1], gs_new[2], (int)P, online);

}


// Main
int main() {
  int i, speed[2];
  char name[20];
  
  // Intialize Webots
  wb_robot_init();

  // Intialize camera
  WbDeviceTag camera = wb_robot_get_device("camera");
  wb_camera_enable(camera, TIME_STEP);
  
  // Intialize ground sensor
  for (i = 0; i < NB_GROUND_SENS; i++) {
    sprintf(name, "gs%d", i);
    gs[i] = wb_robot_get_device(name);
    wb_distance_sensor_enable(gs[i], TIME_STEP);
  }
  
  // Intialize motors
  left_motor = wb_robot_get_device("left wheel motor");
  right_motor = wb_robot_get_device("right wheel motor");
  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);
  wb_motor_set_velocity(left_motor, 0.0);
  wb_motor_set_velocity(right_motor, 0.0);

  // Main loop 
  for (;;) {
    // Run one simulation step
    wb_robot_step(TIME_STEP);

    // Read ground sensor value
    ReadGroundSensors();
    
    // Speed initialization
    speed[LEFT] = 0;
    speed[RIGHT] = 0;

    // LFM - Line Following Module
    LineFollowingModule();


    if(ontrack){
      speed[LEFT] = lfm_speed[LEFT];
      speed[RIGHT] = lfm_speed[RIGHT];
      // Routines used when detecting the line
      if(!online){
        if(P < 0){
          speed[LEFT] = -LFM_FORWARD_SPEED;
          speed[RIGHT] = LFM_FORWARD_SPEED;
        }
        if(P > 0){
          speed[LEFT] = LFM_FORWARD_SPEED;
          speed[RIGHT] = -LFM_FORWARD_SPEED;
        }
      }
    }

    // When detecting the green color with the three gs sensors, the robot stops (Goal!!!)
    if(gs_new[1]>(GOAL-10) && gs_new[1]<(GOAL+10)){
      if(gs_new[0]>(GOAL-10) && gs_new[0]<(GOAL+10)){
        if(gs_new[2]>(GOAL-10) && gs_new[2]<(GOAL+10)){
          ontrack = FALSE;
        }
      }
    }


    // Speed computation
    wb_motor_set_velocity(left_motor, 0.00628 * speed[LEFT]);
    wb_motor_set_velocity(right_motor, 0.00628 * speed[RIGHT]);

    // Debug Console Print
    if(!ontrack) printf("Goal!!!  \n");

  }
  return 0;
}
