/*
 * File:          e-puck_LF_V1_c.c
 * Date:          2022-jan
 * Description:   Line Follower Example
 * Author:        DrakerDG
 * Modifications: 2
 */

#include <stdio.h>
#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/distance_sensor.h>
#include <webots/camera.h>


// Global defines
int timestep = 0;

// PID factors
float Kp = 0.25;  // (min 0.12 - max 1.00)
float Ki = 0; // 0.01
float Kd = 0.0005;  // 0.0005

// PID errors
long P = 0;
long I = 0;
long D = 0;
long PID = 0;
long oldP = 0;

// Max Speed
#define FWD_SPEED 1000

// Speed Motors
int left_speed = 0;
int right_speed = 0;

// Ground Sensor Thresholds
#define MAX_GS 880
#define MIN_GS 300
#define NEW_GS 1000

bool online = false;

// Motors
WbDeviceTag left_motor, right_motor;

// 3 IR ground color sensors
WbDeviceTag gs[3]; /* ground sensors */
short gs_val[3] = {0, 0, 0};
short gs_new[3] = {0, 0, 0};

// Read Ground Sensors Module
long Error_Position(long Pos){
  online = false;
  long PosX = 0;
  int LneX = 0;
    
  for(int i = 0; i < 3; i++){
    gs_val[i] = wb_distance_sensor_get_value(gs[i]);

    // linear Interpolation
    gs_new[i] = ((float)gs_val[i]-MIN_GS)/(MAX_GS-MIN_GS)*-NEW_GS+NEW_GS;

    // Limited values between 0 and 1000 (NEW_GS)
    if(gs_new[i] > NEW_GS) gs_new[i] = NEW_GS;
    if(gs_new[i] < 0) gs_new[i] = 0;
    
    if(gs_new[i] > 200) online = true;
    if(gs_new[i] > 50){
      // Average groud sensor value
      PosX += (long)gs_new[i] * (i * NEW_GS);
      // Sum ground sensor value
      LneX += gs_new[i];
    }
  }

//  printf("GS val: %4d %4d %4d  \n", gs_val[0], gs_val[1], gs_val[2]);
//  printf("GS new: %4d %4d %4d  \n", gs_new[0], gs_new[1], gs_new[2]);

  if(online) return PosX/LneX - NEW_GS; // Position Calculation
  else if(Pos < 0) return -NEW_GS; // Left Sensor Memory Position
  else return NEW_GS; // Right Sensor Memory Position


}


// Line Following Module
void LineFollowingModule(void) {
  int med_speed = 0;
  // Error Position Calculation PID
  P = Error_Position(P);
  I += P * timestep / 1000 ;
  D = D * 0.5 + (P - oldP) / timestep * 1000;

  PID = Kp * P + Ki * I + Kd * D;
  
  oldP = P;
  
  med_speed = FWD_SPEED - abs(PID);
  left_speed = med_speed + PID;
  right_speed = med_speed - PID;

  printf("Perr: %6d    Ierr: %6d    Derr: %6d    |    P:%6d    I:%6d    D:%6d    |    PID: %4d    OnLine: %d \n", (int)P, (int)I, (int)D, (int)(Kp*P), (int)(Ki*I), (int)(Kd*D), (int)PID, online);

}


// Main
int main(int argc, char **argv) {
  char name[20];
  
  // Intialize Webots
  wb_robot_init();

  // Initalize time step
  timestep = wb_robot_get_basic_time_step();

  // Intialize motors
  left_motor = wb_robot_get_device("left wheel motor");
  right_motor = wb_robot_get_device("right wheel motor");
  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);
  wb_motor_set_velocity(left_motor, left_speed);
  wb_motor_set_velocity(right_motor, right_speed);

  // Intialize ground sensors
  for (int i = 0; i < 3; i++) {
    sprintf(name, "gs%d", i);
    gs[i] = wb_robot_get_device(name);
    wb_distance_sensor_enable(gs[i], timestep);
  }
  
  // Intialize camera
  WbDeviceTag camera = wb_robot_get_device("camera");
  wb_camera_enable(camera, timestep);
  
  // Main loop 
  while (wb_robot_step(timestep) != -1) {

    // Line Following Module
    LineFollowingModule();

    // Speed computation
    wb_motor_set_velocity(left_motor, 0.00628 * left_speed);
    wb_motor_set_velocity(right_motor, 0.00628 * right_speed);

  }
  return 0;
}
