/*
 * File:          e-puck_LF_V2.c
 * Date:          2022-jan
 * Description:   Line Follower Example
 * Author:        DrakerDG
 * Modifications: 2
 */

#include <stdio.h>
#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/distance_sensor.h>
#include <webots/camera.h>


// Global defines
int timestep = 0;

// PID factors
float Kp = 0.11;   // 0.1
float Ki = 0.000
; // 0.0002
float Kd = 0.002;  // 0.002

// PID errors
long P = 0;
long I = 0;
long D = 0;
long PID = 0;
long oldP = 0;

// Speed Base
#define FWD_SPEED 500

// Speed Motors
int left_speed = 0;
int right_speed = 0;

// Ground Sensor Thresholds
#define MAX_GS 880
#define MIN_GS 300
#define NEW_GS 1000
#define GOAL 346 //Green of Goal!!!

bool ontrack = true;
bool online = false;

// Motors
WbDeviceTag left_motor, right_motor;

// 3 IR ground color sensors
WbDeviceTag gs[3]; /* ground sensors */
short gs_val[3] = {0, 0, 0};
short gs_new[3] = {0, 0, 0};

// Read Ground Sensors Module
long Error_Position(long Pos){
  online = false;
  long PosX = 0;
  int LneX = 0;
    
  for(int i = 0; i < 3; i++){
    gs_val[i] = wb_distance_sensor_get_value(gs[i]);

    // linear Interpolation
    gs_new[i] = ((float)gs_val[i]-MIN_GS)/(MAX_GS-MIN_GS)*-NEW_GS+NEW_GS;

    // Limited values between 0 and 1000 (NEW_GS)
    if(gs_new[i] > NEW_GS) gs_new[i] = NEW_GS;
    if(gs_new[i] < 0) gs_new[i] = 0;
    
    if(gs_new[i] > 200) online = true;
    if(gs_new[i] > 50){
      // Average groud sensor value
      PosX += (long)gs_new[i] * (i * NEW_GS);
      // Sum ground sensor value
      LneX += gs_new[i];
    }
  }
  if(online) return PosX/LneX - NEW_GS; // Position Calculation
  else if(Pos < 0) return -NEW_GS; // Left Sensor Memory Position
  else return NEW_GS; // Right Sensor Memory Position

//  printf("GS val: %4d %4d %4d  \n", gs_value[0], gs_value[1], gs_value[2]);
//  printf("GS new: %4d %4d %4d  \n", gs_new[0], gs_new[1], gs_new[2]);

}


// Line Following Module
void LineFollowingModule(void) {
  // Error Position Calculation PID
  P = Error_Position(P);
  I = P * timestep / 1000 ;
  D = D * 0.5 + (P - oldP) / timestep * 1000;

  PID = Kp * P + Ki * I + Kd * D;
  
  oldP = P;
  
  if(online) {
    left_speed = FWD_SPEED + PID;
    right_speed = FWD_SPEED - PID;
  }
  else {
    if(P < 0){
      left_speed = -FWD_SPEED;
      right_speed = FWD_SPEED;
    }
    if(P > 0){
      left_speed = FWD_SPEED;
      right_speed = -FWD_SPEED;
    }
  }
  
  if(left_speed > 1000) left_speed = 1000;
  else if(left_speed < -1000) left_speed = -1000;
  if(right_speed > 1000) right_speed = 1000;
  else if(right_speed < -1000) right_speed = -1000;

  printf("%4d   %4d   %4d   %5d   OnLine: %d \n", gs_new[0], gs_new[1], gs_new[2], (int)P, online);

}


// Main
int main(int argc, char **argv) {
  char name[20];
  
  // Intialize Webots
  wb_robot_init();

  // Initalize time step
  timestep = wb_robot_get_basic_time_step();

  // Intialize motors
  left_motor = wb_robot_get_device("left wheel motor");
  right_motor = wb_robot_get_device("right wheel motor");
  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);
  wb_motor_set_velocity(left_motor, left_speed);
  wb_motor_set_velocity(right_motor, right_speed);

  // Intialize ground sensors
  for (int i = 0; i < 3; i++) {
    sprintf(name, "gs%d", i);
    gs[i] = wb_robot_get_device(name);
    wb_distance_sensor_enable(gs[i], timestep);
  }
  
  // Intialize camera
  WbDeviceTag camera = wb_robot_get_device("camera");
  wb_camera_enable(camera, timestep);
  
  // Main loop 
  while (wb_robot_step(timestep) != -1) {

    left_speed = 0;
    right_speed = 0;

    // Line Following Module
    if(ontrack) {
      LineFollowingModule();
    }

    // When detecting the green color with the three gs sensors, the robot stops (Goal!!!)
    if(gs_new[1]>(GOAL-10) && gs_new[1]<(GOAL+10)){
      if(gs_new[0]>(GOAL-10) && gs_new[0]<(GOAL+10)){
        if(gs_new[2]>(GOAL-10) && gs_new[2]<(GOAL+10)){
          ontrack = false;
        }
      }
    }


    // Speed computation
    wb_motor_set_velocity(left_motor, 0.00628 * left_speed);
    wb_motor_set_velocity(right_motor, 0.00628 * right_speed);

    if(!ontrack) printf("Goal!!!  \n");

  }
  return 0;
}
