"""
 * File:          e-puck_LF_V3.py
 * Date:          2022-jan
 * Description:   Line Follower Example
 * Author:        DrakerDG
 * Modifications: 2
"""

from controller import Robot

robot = Robot()

# PID factors
Kp = 0.11    # 0.11
Ki = 0.0002  # 0.0002
Kd = 0.002   # 0.002

# PID errors
P = 0
I = 0
D = 0
PID = 0
oldP = 0

# Speed Base
FWD_SPEED = 500

# Speed Motors
left_speed = 0
right_speed = 0

# Ground Sensor Thresholds
MAX_GS = 880
MIN_GS = 300
NEW_GS = 1000
GOAL = 346 # Green of Goal!!!

ontrack = 1
online = 0

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())

# Initialize Motors
left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(left_speed)
right_motor.setVelocity(right_speed)

# Initialize Ground Sensors
gs = []
gs_val = [0.0,0.0,0.0]
gs_new = [0.0,0.0,0.0]

for i in range(3):
    gsn = robot.getDevice('gs'  + str(i))
    gsn.enable(timestep)
    gs.append(gsn)

# Initialize camera
camera = robot.getDevice('camera')
camera.enable(timestep)

def Error_Position(Pos):
    global online
    online = 0
    PosX = 0
    LneX = 0
    for i in range(3):
        gs_val[i] = gs[i].getValue()
        
        # linear Interpolation
        gs_new[i] = (gs_val[i] - MIN_GS) / (MAX_GS - MIN_GS) * -NEW_GS + NEW_GS
        
        # Limited values between 0 and 1000 (NEW_GS)
        if gs_new[i] > NEW_GS: gs_new[i] = NEW_GS
        if gs_new[i] < 0: gs_new[i] = 0
        
        if gs_new[i] > 200: online = 1
        if gs_new[i] > 50:
            # Average groud sensor value
            PosX += gs_new[i] * (i * NEW_GS)
            # Sum ground sensor value
            LneX += gs_new[i]
    if online == 1: return PosX/LneX - NEW_GS  # Position Calculation
    elif Pos < 0: return -NEW_GS  # Left Sensor Memory Position
    else: return NEW_GS  # Right Sensor Memory Position



# Main loop:
while robot.step(timestep) != -1:
    left_speed = 0
    right_speed = 0

    if ontrack == 1:
        # Error Position Calculation & PID
        P = Error_Position(P)
        I += P * timestep / 1000
        D = D * 0.5 + (P - oldP) / timestep * 1000
        
        PID = Kp * P + Ki * I + Kd * D
        
        oldP = P
        
        if online == 1:
            left_speed = FWD_SPEED + PID
            right_speed = FWD_SPEED - PID
        else:
            if P < 0:
                left_speed = -FWD_SPEED
                right_speed = FWD_SPEED
            if P > 0:
                left_speed = FWD_SPEED
                right_speed = -FWD_SPEED
        
        if left_speed > 1000: left_speed = 1000
        elif left_speed < -1000: left_speed = -1000
        if right_speed > 1000: right_speed = 1000
        elif right_speed < -1000: right_speed = -1000
    
        strP = f'{gs_new[0]:.0f}  {gs_new[1]:.0f}  {gs_new[2]:.0f}  {P:.0f}  online: {online:.0f}'
        print(strP)


    # When detecting the green color with the three gs sensors, the robot stops (Goal!!!)
    if gs_new[1] > GOAL-10 and gs_new[1] < GOAL+10:
        if gs_new[0] > GOAL-10 and gs_new[0] < GOAL+10:
            if gs_new[2] > GOAL-10 and gs_new[2] < GOAL+10:
                ontrack = 0

    left_motor.setVelocity(0.00628 * left_speed)
    right_motor.setVelocity(0.00628 * right_speed)

    if ontrack == 0: print('Goal!!!')

    pass

# Enter here exit cleanup code.
