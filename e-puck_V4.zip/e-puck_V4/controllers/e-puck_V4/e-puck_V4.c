/*

*/

#include <stdio.h>
#include <webots/camera.h>
#include <webots/distance_sensor.h>
#include <webots/motor.h>
#include <webots/robot.h>


// Global defines
#define TRUE 1
#define FALSE 0
#define LEFT 0
#define RIGHT 1
#define TIME_STEP 32  // [ms]

// 8 IR proximity sensors
#define NB_DIST_SENS 8

WbDeviceTag ps[NB_DIST_SENS]; /* proximity sensors */
int ps_value[NB_DIST_SENS] = {0, 0, 0, 0, 0, 0, 0, 0};

// 3 IR ground color sensors
#define NB_GROUND_SENS 3
WbDeviceTag gs[NB_GROUND_SENS]; /* ground sensors */
unsigned short gs_value[NB_GROUND_SENS] = {0, 0, 0};

// Motors
WbDeviceTag left_motor, right_motor;

// obstacle avoidance strategy
#define PS_A 280 //300
#define PS_B 100 //100
#define PS_C 80 //80
#define MAX_GS 880 //840
#define MIN_GS 300
#define NEW_GS 1000
#define GOAL 346 //Green of goal

bool ontrack = TRUE;
bool avoiding = FALSE;
bool around = FALSE;
bool recovery = FALSE;
bool turnL = FALSE;
bool turnR = FALSE;
bool stopRobot = FALSE;
bool online = FALSE;


short gs_new[NB_GROUND_SENS] = {0, 0, 0};

unsigned long Position = 0;

int lfm_speed[2];

// PID errors
long P=0, I=0, D=0, pErr=0, PID=0;

// PID factors
float Kp=0.15;   // 0.25
float Ki=0.0001; // 0.001
float Kd=0.002;  // 0.02

// Max Speed
#define LFM_FORWARD_SPEED 550


// Read Proximity Sensors Module
void ReadProximitySensors(void){
  for (int i = 0; i < NB_DIST_SENS; i++) {
    ps_value[i] = wb_distance_sensor_get_value(ps[i]);
  }
}


// Read Ground Sensors Module
void ReadGroundSensors(void){
  online = false;
  unsigned long avgS = 0;
  unsigned int sumS = 0;
    
  for(int i=0; i<NB_GROUND_SENS; i++){
    gs_value[i] = wb_distance_sensor_get_value(gs[i]);

    // linear Interpolation
    gs_new[i] = ((float)gs_value[i]-MIN_GS)/(MAX_GS-MIN_GS)*-NEW_GS+NEW_GS;

    // Limited values between 0 and 1000 (NEW_GS)
    if(gs_new[i]>NEW_GS) gs_new[i]=NEW_GS;
    if(gs_new[i]<0) gs_new[i]=0;
    
    if(gs_new[i]>200)online = TRUE;
    if(gs_new[i]>50){
      // Average groud sensor value
      avgS += (unsigned long)gs_new[i]*(i*NEW_GS);
      // Sum ground sensor value
      sumS += gs_new[i];
    }
  }
  if(online)Position = avgS/sumS; // Position Calculation
  else if(Position < NEW_GS)Position = 0; // Left Sensor Memory Position
  else Position = NEW_GS*2; // Right Sensor Memory Position

//  printf("GS val: %4d %4d %4d  \n", gs_value[0], gs_value[1], gs_value[2]);
//  printf("GS new: %4d %4d %4d  \n", gs_new[0], gs_new[1], gs_new[2]);

}


// Line Following Module
void LineFollowingModule(void) {
  // Error Position Calculation PID
  P = Position - NEW_GS;
  I = P * TIME_STEP / 1000 ;
  D = D * 0.5 + (P - pErr) / TIME_STEP * 1000;

  PID = Kp * P + Ki * I + Kd * D;
  
  pErr = P;
  
    
  lfm_speed[LEFT] = LFM_FORWARD_SPEED + PID;
  lfm_speed[RIGHT] = LFM_FORWARD_SPEED - PID;
  
  if(lfm_speed[LEFT] > 1000) lfm_speed[LEFT] = 1000;
  else if(lfm_speed[LEFT] < -1000) lfm_speed[LEFT] = -1000;
  if(lfm_speed[RIGHT] > 1000) lfm_speed[RIGHT] = 1000;
  else if(lfm_speed[RIGHT] < -1000) lfm_speed[RIGHT] = -1000;

  printf("%4d   %4d   %4d   %5d   OnLine: %d   Left: %d   Right: %d  \n", gs_new[0], gs_new[1], gs_new[2], (int)P, online, turnL, turnR);

}


// Main
int main() {
  int i, speed[2];
  
  // Intialize Webots
  wb_robot_init();

  // Intialize camera
  WbDeviceTag camera = wb_robot_get_device("camera");
  wb_camera_enable(camera, TIME_STEP);
  
  // Intialize proximiry sensor
  char name[20];
  for (i = 0; i < NB_DIST_SENS; i++) {
    sprintf(name, "ps%d", i);
    ps[i] = wb_robot_get_device(name);
    wb_distance_sensor_enable(ps[i], TIME_STEP);
  }

  // Intialize ground sensor
  for (i = 0; i < NB_GROUND_SENS; i++) {
    sprintf(name, "gs%d", i);
    gs[i] = wb_robot_get_device(name);
    wb_distance_sensor_enable(gs[i], TIME_STEP);
  }
  
  // Intialize motors
  left_motor = wb_robot_get_device("left wheel motor");
  right_motor = wb_robot_get_device("right wheel motor");
  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);
  wb_motor_set_velocity(left_motor, 0.0);
  wb_motor_set_velocity(right_motor, 0.0);

  // Main loop 
  for (;;) {
    // Run one simulation step
    wb_robot_step(TIME_STEP);

    // Read proximity sensors value
    ReadProximitySensors();
    
    // Read ground sensor value
    ReadGroundSensors();
    
    // Speed initialization
    speed[LEFT] = 0;
    speed[RIGHT] = 0;

    // LFM - Line Following Module
    LineFollowingModule();


    if(ontrack){
      speed[LEFT] = lfm_speed[LEFT];
      speed[RIGHT] = lfm_speed[RIGHT];
      // Routines used when detecting the line
      if(online){
        // If the center sensor detects the line
        
        if(gs_new[0]>(GOAL-10) && gs_new[0]<(GOAL+10) && gs_new[2]<(40)) turnL = TRUE;
        if (P == 0 && turnL) ontrack = FALSE;
      }
      //Routine braking and recovery when losing the line
      else{
        if(P == -NEW_GS){
          speed[LEFT] = -LFM_FORWARD_SPEED;
          speed[RIGHT] = LFM_FORWARD_SPEED;
        }
        if(P == NEW_GS){
          speed[LEFT] = LFM_FORWARD_SPEED;
          speed[RIGHT] = -LFM_FORWARD_SPEED;
        }
      }
    }
    // Crossover routine used for bifurcation
    else{
      if(turnL && !stopRobot){
        speed[LEFT] = -LFM_FORWARD_SPEED;
        speed[RIGHT] = LFM_FORWARD_SPEED;
        if(gs_new[0]<40 && gs_new[1]<40 && gs_new[2]>700) {
          turnL = FALSE;
          ontrack = TRUE;
        }
      }
    }

    // When detecting the green color with the three gs sensors, the robot stops (Goal!!!)
    if(gs_new[1]>(GOAL-10) && gs_new[1]<(GOAL+10)){
      if(gs_new[0]>(GOAL-10) && gs_new[0]<(GOAL+10)){
        if(gs_new[2]>(GOAL-10) && gs_new[2]<(GOAL+10)){
          ontrack = FALSE;
          stopRobot = TRUE;
        }
      }
    }

    // When it is detecting an object on the front
    if(ps_value[7] > PS_A || ps_value[0] > PS_A){
      avoiding = TRUE;
      ontrack = FALSE;
    }

    // The robot rotates until the ps5 sensor detects the object on the left
    if(avoiding){
      if(ps_value[5] < (PS_A-20)){
        speed[LEFT] = LFM_FORWARD_SPEED;
        speed[RIGHT] = -LFM_FORWARD_SPEED;
      }
      else if(ps_value[5] >= PS_A){
        avoiding = FALSE;
        around = TRUE;
      }
    }

    // The robot circles the object until it detects the line again.    
    if(around){
      if(ps_value[5] < (PS_A-20) && ps_value[6] < PS_B){
        speed[LEFT] = -LFM_FORWARD_SPEED;
        speed[RIGHT] = LFM_FORWARD_SPEED;
      }
      else{
        speed[LEFT] = LFM_FORWARD_SPEED;
        speed[RIGHT] = LFM_FORWARD_SPEED;
      }
      if(gs_new[0]>800 || gs_new[1]>800 || gs_new[2]>800){
        around = FALSE;
        recovery = TRUE;
      }
    }   

    // The robot rotates until the ps5 sensor stops detecting the obstacle     
    if(recovery){
      if(ps_value[5] > PS_C){
        speed[LEFT] = LFM_FORWARD_SPEED;
        speed[RIGHT] = -LFM_FORWARD_SPEED;
      }
      else if(gs_new[0]>800){
        speed[LEFT] = LFM_FORWARD_SPEED;
        speed[RIGHT] = LFM_FORWARD_SPEED;
      }
      else{
        recovery = FALSE;
        ontrack = TRUE;
      }
    }

    // Speed computation
    wb_motor_set_velocity(left_motor, 0.00628 * speed[LEFT]);
    wb_motor_set_velocity(right_motor, 0.00628 * speed[RIGHT]);

    // Debug Console Print
    if(stopRobot) printf("Goal!!!  \n");
    else printf("Ontrack: %d   Avoiding: %d   Around: %d   Recovey: %d   Left Bifurcation: %d   \n", !(avoiding || around || recovery), avoiding, around, recovery, turnL);
  

  }
  return 0;
}
